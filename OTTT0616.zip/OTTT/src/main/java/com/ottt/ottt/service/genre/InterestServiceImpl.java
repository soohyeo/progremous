package com.ottt.ottt.service.genre;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ottt.ottt.dao.genre.InterestDao;
import com.ottt.ottt.dto.ContentDTO;

@Service
public class InterestServiceImpl implements InterestService{
	
	@Autowired
	InterestDao interestDao;
	
	@Override
	public List<ContentDTO> getInterest() throws Exception {
		// TODO Auto-generated method stub
		return interestDao.interestSelect();
	}

}
