package com.ottt.ottt.service.genre;

import java.util.List;

import com.ottt.ottt.dto.ContentDTO;

public interface DramaService {

	List<ContentDTO> getDrama() throws Exception;
}
