function showCalendar() {
    var selectBox = document.getElementById("calendarSelect");
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;

    var calendarContainer = document.getElementById("calendarContainer");
    calendarContainer.innerHTML = ""; // 기존에 생성된 테이블이 있으면 삭제

    if (selectedValue === "table1") {
        // 테이블 1 생성
        var table1 = document.createElement("table");
        // 테이블 내용 추가
        // ...

        calendarContainer.appendChild(table1); // 테이블 1을 표시
    } else if (selectedValue === "table2") {
        // 테이블 2 생성
        var table2 = document.createElement("table");
        // 테이블 내용 추가
        // ...

        calendarContainer.appendChild(table2); // 테이블 2를 표시
    }
    // 추가적인 테이블 생성에 대한 조건문 추가
}