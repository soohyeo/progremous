package com.ottt.ottt.dao.genre;

import java.util.List;

import com.ottt.ottt.dto.ContentDTO;


public interface MovieDao {

	List<ContentDTO> movieSelect() throws Exception;
}
