package com.ottt.ottt.service.genre;

import java.util.List;

import com.ottt.ottt.dto.ContentDTO;

public interface AnimationService {

	List<ContentDTO> getAnimation() throws Exception;
}
