package com.ottt.ottt.controller.community;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ottt.ottt.dto.EndServiceDTO;
import com.ottt.ottt.service.community.EndmovieService.EndMovieService;

@Controller
@RequestMapping("/community")
public class EndmovieController {
	
	@Autowired
	EndMovieService endMovieService;

	@GetMapping(value = "/endmovie")
	public String endmovie(String month, Model m) {
		
		if(month == null) {
			month = "05";
		}
		
		String end_date_1_str = "2023" + month + "01";
		String end_date_2_str = "2023" + month + "30";
		
		SimpleDateFormat dtFormat = new SimpleDateFormat("yyyy/MM/dd");
		
		
		try {
			Date end_date_1 = dtFormat.parse(end_date_1_str);
			Date end_date_2 = dtFormat.parse(end_date_2_str);
			List<EndServiceDTO> list = endMovieService.endDateSelect(end_date_1, end_date_2);
			m.addAttribute("month", month);
		    m.addAttribute("list", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "/community/endmovie/endmovie2";
	}
	
	@GetMapping(value = "/endmovie/{ott_no}")
	public String endmovieCoupang(Integer ott_no) {
		try {
			endMovieService.endOttSelect(ott_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/community/endmovie/coupang";		
	}
	
	@GetMapping(value = "/endmovie/disney")
	public String endmovieDisney() {
			return "/community/endmovie/disney";		
	}
	
	@GetMapping(value = "/endmovie/netflix")
	public String endmovieNetflix() {
			return "/community/endmovie/netflix";		
	}
	
	@GetMapping(value = "/endmovie/tving")
	public String endmovieTving() {
			return "/community/endmovie/tving";		
	}
	
	@GetMapping(value = "/endmovie/watcha")
	public String endmovieWatcha() {
			return "/community/endmovie/watcha";		
	}
	
	@GetMapping(value = "/endmovie/wavve")
	public String endmovieWavve() {
			return "/community/endmovie/wavve";		
	}

	//더보기
	@GetMapping(value = "/endmovie/more")
	public String endmovieMore() {
			return "/community/endmovie/month";		
	}
	
}
