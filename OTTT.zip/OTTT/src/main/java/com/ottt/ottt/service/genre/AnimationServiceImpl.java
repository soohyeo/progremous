package com.ottt.ottt.service.genre;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ottt.ottt.dao.genre.AnimationDao;
import com.ottt.ottt.dto.ContentDTO;

@Service
public class AnimationServiceImpl implements AnimationService{

	@Autowired
	AnimationDao animationDao;
	
	@Override
	public List<ContentDTO> getAnimation() throws Exception {
		// TODO Auto-generated method stub
		return animationDao.animationSelect();
	}

}
