package com.ottt.ottt.controller.community;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.ottt.ottt.dto.EndServiceDTO;
import com.ottt.ottt.service.community.EndmovieService.EndMovieService;

@Controller
@RequestMapping("/community")
public class EndmovieController {
	
	@Autowired
	EndMovieService endMovieService;
	
	@GetMapping(value = "/endmovie")
	public String endmovie() {
		
		    return "/community/endmovie/endmovie";
		}
	
	@PostMapping(value = "/endmovie/calendar", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String,Object>> endmovie(@RequestBody Map<String, Object> data
														, Model m) {
		  
		try {
			List<EndServiceDTO> endServiceDTO = endMovieService.getEndServiceList();
			
			
		} catch (Exception e1) {
			
			e1.printStackTrace();
		}
		
		String year = (String) data.get("year");
		String month = (String) data.get("month");
		int ott_no = Integer.parseInt(String.valueOf(data.get("ott_no")));
		// 첫째날 끝날 구하기 구해서 date1, date2 를 스트링으로 만들어내기
		String end_date_1_str = "20230101";
		String end_date_2_str = "20231231";
		SimpleDateFormat dtFormat = new SimpleDateFormat("yyyyMMdd");
		
		try {
			Date end_date_1 = dtFormat.parse(end_date_1_str);
			Date end_date_2 = dtFormat.parse(end_date_2_str);
			List<EndServiceDTO> list = endMovieService.endDateSelect(ott_no, end_date_1, end_date_2);
			System.out.println("goodboyList");
			System.out.println(list);
			System.out.println("goodboyList");
			
			// [{day:1, content: "택배기사"}, {day:2, content: "쥬라기공원"}]

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Map<String, Object> processedMap = new HashMap<>();

		List<EndServiceDTO> list;
		try {
			list = endMovieService.getEndServiceList();
			List<Map<String, Object>> processedList = new ArrayList<>();
			for (EndServiceDTO dto : list) {
			    Map<String, Object> entry = new HashMap<>();
			    entry.put("day", dto.getDay());
			    entry.put("content", dto.getContent());
			    processedList.add(entry);
			    System.out.println(processedList); // 가공된 리스트 출력

				processedMap.put("data", processedList);
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 주어진 리스트

		return ResponseEntity.ok(processedMap);
	}
	
	@GetMapping(value = "/endmovie/{ott_no}")
	public String endmovieCoupang(Integer ott_no) {
		try {
			System.out.println("요청");
			endMovieService.endOttSelect(ott_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/community/endmovie/coupang";
	}
}
