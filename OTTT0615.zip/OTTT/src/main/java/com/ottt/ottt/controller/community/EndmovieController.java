package com.ottt.ottt.controller.community;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.ottt.ottt.dto.EndServiceDTO;
import com.ottt.ottt.service.community.EndmovieService.EndMovieService;

@Controller
@RequestMapping("/community")
public class EndmovieController {
	
	@Autowired
	EndMovieService endMovieService;
	
	@GetMapping(value = "/endmovie")
	public String endmovie() {
		
		    return "/community/endmovie/endmovie";
		}
	
	@PostMapping(value = "/endmovie/calendar", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String,Object>> endservice(Integer ott_no, String year, String month) throws Exception {
		List<EndServiceDTO> endServiceDTO = endMovieService.getEndServiceList();
		//String year = (String)
		List<EndServiceDTO> lvo = endMovieService.endDateSelect(ott_no, year, month);
		//Integer ott_no = (int) endServiceDTO.get(ott_no);
		// 첫째날 끝날 구하기 구해서 date1, date2 를 스트링으로 만들어내기 
		String end_date_1_str = year + month + "01";
		String end_date_2_str = (year != null && month != null) ? year + month + LocalDate.of(Integer.parseInt(year), Integer.parseInt(month), 1).lengthOfMonth() : "Default value";
		SimpleDateFormat dtFormat = new SimpleDateFormat("yyyyMMdd");
		
		try {
			Date end_date_1 = dtFormat.parse(end_date_1_str);
			Date end_date_2 = dtFormat.parse(end_date_2_str);
			List<EndServiceDTO> list = endMovieService.dayDateSelect(ott_no, end_date_1, end_date_2);
			System.out.println(list);
			// [{day:1, content: "택배기사"}, {day:2, content: "쥬라기공원"}]

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Map<String, Object> response = new HashMap<String, Object>();
		return ResponseEntity.ok(response);
	}
	
	@GetMapping(value = "/endmovie/{ott_no}")
	public String endmovieCoupang(Integer ott_no) {
		try {
			System.out.println("요청");
			endMovieService.endOttSelect(ott_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/community/endmovie/coupang";
	}
}
