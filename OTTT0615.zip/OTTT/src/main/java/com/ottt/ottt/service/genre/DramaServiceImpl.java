package com.ottt.ottt.service.genre;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ottt.ottt.dao.genre.DramaDao;
import com.ottt.ottt.dto.ContentDTO;

@Service
public class DramaServiceImpl implements DramaService{

	@Autowired
	DramaDao dramaDao;
	
	
	@Override
	public List<ContentDTO> getDrama() throws Exception {
		// TODO Auto-generated method stub
		return dramaDao.dramaSelect();
	}
}
