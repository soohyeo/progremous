function open(){
  window.open("url", "_blank", "width=500, height=500");
}